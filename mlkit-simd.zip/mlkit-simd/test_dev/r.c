#include <stdio.h>

double a = 1.8;

int main() {
  double b = 0 - a;
  printf("%f\n", b);
  return 0;
}

Programs that work with the KAM backend:

 a.pm                                 ok
 b.pm                                 ok
 exn1.sml                             ok
 exn2.sml                             ok
 exn3.sml                             ok
 exn4.sml                             ok
 exception1.sml                       ok
 exception2.sml                       ok
 exception3.sml                       ok
 exception4.sml                       ok
 exception5.sml                       ok
 f1.sml                               ok
 f2.sml                               ok
 fft_no_basislib.sml
 fib.sml                              ok
 fib0.sml                             ok
 foldl.sml                            ok
 global_region.sml                    ok
 hanoi.sml                            ok
 hello.sml                            ok
 if.sml                               ok
 immedString.sml                      ok
 kitkbjul9_no_basislib.sml            overs�tter men udskriver intet n�r det k�res!
 kitlife35u_no_basislib.sml           overs�tter men udskriver intet n�r det k�res!
 kitqsort_no_basislib.sml
 kitreynolds2_no_basislib.sml
 kitreynolds3_no_basislib.sml
 kitsimple_no_basislib.sml
 kittmergesort_no_basislib.sml
 l1.sml                               ok
 list_nh.sml                          ok
 listpair.sml
 professor_game.sml                   overs�tter men udskriver intet n�r det k�res!
 real1.sml
 ref-int.sml
 ref-real.sml
 ref.sml
 string1.sml
 test_dattyp.sml
 testdyn1.sml
 testdyn2.sml

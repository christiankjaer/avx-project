   CalcInterface.sig
(*   Calculator.sml*)
   CalculatorReg.sml
   TextCalcInterface.sml
   Main.sml

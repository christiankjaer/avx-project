int f(int a, int b, int c, int d, int e, int g) {

  return a + b + c + d + e * 3 + 4 + g;
}

int main() {
  int a, b, c, d, e, g, h, i, j;


  c = f(a,b,c,d, e, g);

  return c;
}

/* pilrc generated file.  Do not edit!*/
#define button1 9997
#define label1 9998
#define form1 9999

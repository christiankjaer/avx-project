#include "../src/Runtime/Tagging.h"

int select_second(int pair) {
  return second(pair);
}

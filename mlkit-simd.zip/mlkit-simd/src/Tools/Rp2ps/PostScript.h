#ifndef _POSTSCRIPT_H
#define _POSTSCRIPT_H

#include "Output.h"

extern Format PsOutput;

#endif /* _POSTSCRIPT_H */

#ifndef ERROR
#define ERROR

void Disaster(char* format);

#endif /* ERROR */

/* Do *NOT* edit this file - it is auto-generated with Tools/GenOpcodes */
/* based on the files [Compiler/Backend/KAM/BuiltInCFunctions.spec, Compiler/Backend/KAM/BuiltInCFunctionsApSml.spec] */

#include "Prims.h"

extern int stdErrStream();
extern int stdOutStream();
extern int stdInStream();
extern int sqrtFloat();
extern int lnFloat();
extern int negInfFloat();
extern int posInfFloat();
extern int sml_getrutime();
extern int sml_getrealtime();
extern int sml_localoffset();
extern int exnNameML();
extern int printReal();
extern int printStringML();
extern int printNum();
extern int printList();
extern int implodeCharsML();
extern int implodeStringML();
extern int concatStringML();
extern int __div_int32ub();
extern int __div_int31();
extern int __div_word32ub();
extern int __div_word31();
extern int __mod_int32ub();
extern int __mod_int31();
extern int __mod_word32ub();
extern int __mod_word31();
extern int word_table0();
extern int word_table_init();
extern int allocStringML();
extern int chrCharML();
extern int greaterStringML();
extern int lessStringML();
extern int lesseqStringML();
extern int greatereqStringML();
extern int equalStringML();
extern int __quot_int32ub();
extern int __quot_int31();
extern int __rem_int32ub();
extern int __rem_int31();
extern int divFloat();
extern int sinFloat();
extern int cosFloat();
extern int atanFloat();
extern int asinFloat();
extern int acosFloat();
extern int atan2Float();
extern int expFloat();
extern int powFloat();
extern int sinhFloat();
extern int coshFloat();
extern int tanhFloat();
extern int floorFloat();
extern int ceilFloat();
extern int truncFloat();
extern int stringOfFloat();
extern int isnanFloat();
extern int realInt();
extern int generalStringOfFloat();
extern int sml_real_to_bytes();
extern int sml_bytes_to_real();
extern int closeStream();
extern int openInStream();
extern int openOutStream();
extern int openAppendStream();
extern int flushStream();
extern int outputStream();
extern int outputBinStream();
extern int inputStream();
extern int input1Stream();
extern int lookaheadStream();
extern int openInBinStream();
extern int openOutBinStream();
extern int openAppendBinStream();
extern int sml_errormsg();
extern int sml_errno();
extern int sml_access();
extern int sml_getdir();
extern int sml_isdir();
extern int sml_mkdir();
extern int sml_chdir();
extern int sml_readlink();
extern int sml_islink();
extern int sml_realpath();
extern int sml_devinode();
extern int sml_rmdir();
extern int sml_modtime();
extern int sml_filesize();
extern int sml_remove();
extern int sml_rename();
extern int sml_settime();
extern int sml_opendir();
extern int sml_readdir();
extern int sml_rewinddir();
extern int sml_closedir();
extern int sml_system();
extern int sml_getenv();
extern int terminateML();
extern int sml_commandline_name();
extern int sml_commandline_args();
extern int sml_localtime();
extern int sml_gmtime();
extern int sml_mktime();
extern int sml_asctime();
extern int sml_strftime();
extern int precision();
extern int get_time_base();
extern int min_fixed_int();
extern int max_fixed_int();
extern int sml_dlopen();
extern int resolveFun();
extern int isResolvedFun();
extern int fromCtoMLstring();
extern int sml_WIFEXITED();
extern int sml_WIFSIGNALED();
extern int sml_WIFSTOPPED();
extern int sml_WEXITSTATUS();
extern int sml_WTERMSIG();
extern int sml_WSTOPSIG();
extern int sml_waitpid();
extern void exit();
extern int fork();
extern int sml_getStdNumbers();
extern int sml_microsleep();
extern int sml_exec();
extern int sml_sysconf();
extern int sml_times();
extern int sml_lower();
extern int link();
extern int rename();
extern int symlink();
extern int unlink();
extern int rmdir();
extern int chown();
extern int fchown();
extern int sml_pipe();
extern int close();
extern int sml_dupfd();
extern int isatty();
extern int sml_setFailNumber();
extern int sml_syserror();
extern int sml_findsignal();
extern int sml_errorName();
extern int alarm();
extern int kill();
extern int pause();
extern int sml_ctermid();
extern int sml_environ();
extern int getegid();
extern int getgid();
extern int geteuid();
extern int getuid();
extern int sml_getgroups();
extern int sml_getlogin();
extern int getpgrp();
extern int getpid();
extern int getppid();
extern int setgid();
extern int setsid();
extern int sml_gettime();
extern int sml_ttyname();
extern int setuid();
extern int setpgid();
extern int sml_uname();
extern int sml_lseek();
extern int sml_readVec();
extern int sml_writeVec();
extern int sml_readArr();
extern int sml_isreg();
extern int sml_setfl();
extern int sml_getfl();
extern int sml_filesizefd();
extern int sml_getgrgid();
extern int sml_getgrnam();
extern int sml_getpwnam();
extern int sml_getpwuid();
extern int sml_getTty();
extern int sml_fpathconf();
extern int sml_pathconf();
extern int ftruncate();
extern int sml_stat();
extern int sml_fstat();
extern int sml_lstat();
extern int ap_internal_redirect();
extern int apsml_rputs();
extern int apsml_returnHtml();
extern int apsml_returnRedirect();
extern int apsml_returnFile();
extern int apsml_log();
extern int apsml_getport();
extern int apsml_gethost();
extern int apsml_getserver();
extern int apsml_geturl();
extern int apsml_getpeer();
extern int apsml_getQueryData();
extern int apsml_headers();
extern int apsml_add_headers_out();
extern int apsml_PageRoot();
extern int apsml_encodeUrl();
extern int apsml_decodeUrl();
extern int apsml_method();
extern int apsml_scheme();
extern int apsml_contentlength();
extern int apsml_setMimeType();
extern int apsml_cacheCreate();
extern int apsml_cacheFind();
extern int apsml_cacheFlush();
extern int apsml_cacheSet();
extern int apsml_cacheGet();
extern int apsml_GetReqRec();
extern int apsml_conflookup();
extern int apsml_confinsert();
extern int apdns_getFQDN_MX();
extern int apsml_sendmail();
extern int apsml_mailget();
extern int apsml_mailer_initconn();
extern int apsml_closeconn();
extern int apsml_mailGetError();
extern int apsml_errnoToString();
extern int apsml_mailer_initconnCheckCon();
extern int apsml_getuptime();
extern int apsml_reg_schedule();
extern int apsml_getpage();
extern int getMaxHeapPoolSz();
extern int setMaxHeapPoolSz();
extern int sml_getAuxData();
extern int apsml_getuser();
extern int apsml_get_auth_type();
extern int apsml_mkrequest();

c_primitive cprim[] = {
  (c_primitive)stdErrStream,
  (c_primitive)stdOutStream,
  (c_primitive)stdInStream,
  (c_primitive)sqrtFloat,
  (c_primitive)lnFloat,
  (c_primitive)negInfFloat,
  (c_primitive)posInfFloat,
  (c_primitive)sml_getrutime,
  (c_primitive)sml_getrealtime,
  (c_primitive)sml_localoffset,
  (c_primitive)exnNameML,
  (c_primitive)printReal,
  (c_primitive)printStringML,
  (c_primitive)printNum,
  (c_primitive)printList,
  (c_primitive)implodeCharsML,
  (c_primitive)implodeStringML,
  (c_primitive)concatStringML,
  (c_primitive)__div_int32ub,
  (c_primitive)__div_int31,
  (c_primitive)__div_word32ub,
  (c_primitive)__div_word31,
  (c_primitive)__mod_int32ub,
  (c_primitive)__mod_int31,
  (c_primitive)__mod_word32ub,
  (c_primitive)__mod_word31,
  (c_primitive)word_table0,
  (c_primitive)word_table_init,
  (c_primitive)allocStringML,
  (c_primitive)chrCharML,
  (c_primitive)greaterStringML,
  (c_primitive)lessStringML,
  (c_primitive)lesseqStringML,
  (c_primitive)greatereqStringML,
  (c_primitive)equalStringML,
  (c_primitive)__quot_int32ub,
  (c_primitive)__quot_int31,
  (c_primitive)__rem_int32ub,
  (c_primitive)__rem_int31,
  (c_primitive)divFloat,
  (c_primitive)sinFloat,
  (c_primitive)cosFloat,
  (c_primitive)atanFloat,
  (c_primitive)asinFloat,
  (c_primitive)acosFloat,
  (c_primitive)atan2Float,
  (c_primitive)expFloat,
  (c_primitive)powFloat,
  (c_primitive)sinhFloat,
  (c_primitive)coshFloat,
  (c_primitive)tanhFloat,
  (c_primitive)floorFloat,
  (c_primitive)ceilFloat,
  (c_primitive)truncFloat,
  (c_primitive)stringOfFloat,
  (c_primitive)isnanFloat,
  (c_primitive)realInt,
  (c_primitive)generalStringOfFloat,
  (c_primitive)sml_real_to_bytes,
  (c_primitive)sml_bytes_to_real,
  (c_primitive)closeStream,
  (c_primitive)openInStream,
  (c_primitive)openOutStream,
  (c_primitive)openAppendStream,
  (c_primitive)flushStream,
  (c_primitive)outputStream,
  (c_primitive)outputBinStream,
  (c_primitive)inputStream,
  (c_primitive)input1Stream,
  (c_primitive)lookaheadStream,
  (c_primitive)openInBinStream,
  (c_primitive)openOutBinStream,
  (c_primitive)openAppendBinStream,
  (c_primitive)sml_errormsg,
  (c_primitive)sml_errno,
  (c_primitive)sml_access,
  (c_primitive)sml_getdir,
  (c_primitive)sml_isdir,
  (c_primitive)sml_mkdir,
  (c_primitive)sml_chdir,
  (c_primitive)sml_readlink,
  (c_primitive)sml_islink,
  (c_primitive)sml_realpath,
  (c_primitive)sml_devinode,
  (c_primitive)sml_rmdir,
  (c_primitive)sml_modtime,
  (c_primitive)sml_filesize,
  (c_primitive)sml_remove,
  (c_primitive)sml_rename,
  (c_primitive)sml_settime,
  (c_primitive)sml_opendir,
  (c_primitive)sml_readdir,
  (c_primitive)sml_rewinddir,
  (c_primitive)sml_closedir,
  (c_primitive)sml_system,
  (c_primitive)sml_getenv,
  (c_primitive)terminateML,
  (c_primitive)sml_commandline_name,
  (c_primitive)sml_commandline_args,
  (c_primitive)sml_localtime,
  (c_primitive)sml_gmtime,
  (c_primitive)sml_mktime,
  (c_primitive)sml_asctime,
  (c_primitive)sml_strftime,
  (c_primitive)precision,
  (c_primitive)get_time_base,
  (c_primitive)min_fixed_int,
  (c_primitive)max_fixed_int,
  (c_primitive)sml_dlopen,
  (c_primitive)resolveFun,
  (c_primitive)isResolvedFun,
  (c_primitive)fromCtoMLstring,
  (c_primitive)sml_WIFEXITED,
  (c_primitive)sml_WIFSIGNALED,
  (c_primitive)sml_WIFSTOPPED,
  (c_primitive)sml_WEXITSTATUS,
  (c_primitive)sml_WTERMSIG,
  (c_primitive)sml_WSTOPSIG,
  (c_primitive)sml_waitpid,
  (c_primitive)exit,
  (c_primitive)fork,
  (c_primitive)sml_getStdNumbers,
  (c_primitive)sml_microsleep,
  (c_primitive)sml_exec,
  (c_primitive)sml_sysconf,
  (c_primitive)sml_times,
  (c_primitive)sml_lower,
  (c_primitive)link,
  (c_primitive)rename,
  (c_primitive)symlink,
  (c_primitive)unlink,
  (c_primitive)rmdir,
  (c_primitive)chown,
  (c_primitive)fchown,
  (c_primitive)sml_pipe,
  (c_primitive)close,
  (c_primitive)sml_dupfd,
  (c_primitive)isatty,
  (c_primitive)sml_setFailNumber,
  (c_primitive)sml_syserror,
  (c_primitive)sml_findsignal,
  (c_primitive)sml_errorName,
  (c_primitive)alarm,
  (c_primitive)kill,
  (c_primitive)pause,
  (c_primitive)sml_ctermid,
  (c_primitive)sml_environ,
  (c_primitive)getegid,
  (c_primitive)getgid,
  (c_primitive)geteuid,
  (c_primitive)getuid,
  (c_primitive)sml_getgroups,
  (c_primitive)sml_getlogin,
  (c_primitive)getpgrp,
  (c_primitive)getpid,
  (c_primitive)getppid,
  (c_primitive)setgid,
  (c_primitive)setsid,
  (c_primitive)sml_gettime,
  (c_primitive)sml_ttyname,
  (c_primitive)setuid,
  (c_primitive)setpgid,
  (c_primitive)sml_uname,
  (c_primitive)sml_lseek,
  (c_primitive)sml_readVec,
  (c_primitive)sml_writeVec,
  (c_primitive)sml_readArr,
  (c_primitive)sml_isreg,
  (c_primitive)sml_setfl,
  (c_primitive)sml_getfl,
  (c_primitive)sml_filesizefd,
  (c_primitive)sml_getgrgid,
  (c_primitive)sml_getgrnam,
  (c_primitive)sml_getpwnam,
  (c_primitive)sml_getpwuid,
  (c_primitive)sml_getTty,
  (c_primitive)sml_fpathconf,
  (c_primitive)sml_pathconf,
  (c_primitive)ftruncate,
  (c_primitive)sml_stat,
  (c_primitive)sml_fstat,
  (c_primitive)sml_lstat,
  (c_primitive)ap_internal_redirect,
  (c_primitive)apsml_rputs,
  (c_primitive)apsml_returnHtml,
  (c_primitive)apsml_returnRedirect,
  (c_primitive)apsml_returnFile,
  (c_primitive)apsml_log,
  (c_primitive)apsml_getport,
  (c_primitive)apsml_gethost,
  (c_primitive)apsml_getserver,
  (c_primitive)apsml_geturl,
  (c_primitive)apsml_getpeer,
  (c_primitive)apsml_getQueryData,
  (c_primitive)apsml_headers,
  (c_primitive)apsml_add_headers_out,
  (c_primitive)apsml_PageRoot,
  (c_primitive)apsml_encodeUrl,
  (c_primitive)apsml_decodeUrl,
  (c_primitive)apsml_method,
  (c_primitive)apsml_scheme,
  (c_primitive)apsml_contentlength,
  (c_primitive)apsml_setMimeType,
  (c_primitive)apsml_cacheCreate,
  (c_primitive)apsml_cacheFind,
  (c_primitive)apsml_cacheFlush,
  (c_primitive)apsml_cacheSet,
  (c_primitive)apsml_cacheGet,
  (c_primitive)apsml_GetReqRec,
  (c_primitive)apsml_conflookup,
  (c_primitive)apsml_confinsert,
  (c_primitive)apdns_getFQDN_MX,
  (c_primitive)apsml_sendmail,
  (c_primitive)apsml_mailget,
  (c_primitive)apsml_mailer_initconn,
  (c_primitive)apsml_closeconn,
  (c_primitive)apsml_mailGetError,
  (c_primitive)apsml_errnoToString,
  (c_primitive)apsml_mailer_initconnCheckCon,
  (c_primitive)apsml_getuptime,
  (c_primitive)apsml_reg_schedule,
  (c_primitive)apsml_getpage,
  (c_primitive)getMaxHeapPoolSz,
  (c_primitive)setMaxHeapPoolSz,
  (c_primitive)sml_getAuxData,
  (c_primitive)apsml_getuser,
  (c_primitive)apsml_get_auth_type,
  apsml_mkrequest
};

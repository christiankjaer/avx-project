
long callExportFun(const char *fun, long i);


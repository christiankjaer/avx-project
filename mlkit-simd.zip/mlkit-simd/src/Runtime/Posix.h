struct syserr_entry
{
  char *name;
  size_t number;
};

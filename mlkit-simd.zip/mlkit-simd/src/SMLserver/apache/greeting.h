
#include <httpd.h>
void sml_greeting(server_rec *s);

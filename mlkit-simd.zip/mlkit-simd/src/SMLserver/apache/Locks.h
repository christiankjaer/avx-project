#ifndef APACHE_LOCKS_H
#define APACHE_LOCKS_H

void runtime_lock(unsigned int i);
void runtime_unlock(unsigned int i);

#endif // APACHE_LOCKS_H

void plog1s(const char *, void *);
void plog2s(const char *, const char *, void *);
void plog3s(const char *, const char *, const char *, void *);
void plog4s(const char *, const char *, const char *, const char *, void *);
void plog4s1i(const char *, const char *, const char *, const char *, unsigned long, void *);
void plog5s(const char *, const char *, const char *, const char *, const char *, void *);

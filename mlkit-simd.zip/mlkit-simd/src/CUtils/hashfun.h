

unsigned long charhashfunction (const char *key);

-- Load datamodel:
--   mysql dbname -u dbuser < all.sql

\. person.sql
\. link.sql
\. rating.sql
\. employee.sql
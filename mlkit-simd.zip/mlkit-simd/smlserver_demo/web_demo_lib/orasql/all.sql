drop table link;
drop table rating;
drop table wine;
drop table person;
drop table employee;
drop table guest;
@person.sql
@link.sql
@rating.sql
@employee.sql
@guest.sql


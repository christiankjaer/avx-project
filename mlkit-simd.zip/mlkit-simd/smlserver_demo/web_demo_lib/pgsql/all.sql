\i person.sql
\i link.sql
\i employee.sql
\i rating.sql
\i guest.sql

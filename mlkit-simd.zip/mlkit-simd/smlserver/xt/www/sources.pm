import ../libxt/libxt.pm
in
 local ../demolib/page.sml
       ../demolib/data0.sml
 in
    [
     index.sml
     bmiform.sml
     bmiform2.sml
     bmi.sml
     time_of_day.sml
     mul.sml
     temp.sml
     temp2.sml
     count.sml
     sum.sml
     questionnaire.sml
     questionnaire2.sml
     toppings.sml
     toppings2.sml
     countreload.sml
     data.sml
     ]
 end
end
